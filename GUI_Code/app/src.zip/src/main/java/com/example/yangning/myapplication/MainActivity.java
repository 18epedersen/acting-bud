package com.example.yangning.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    EditText inputSearch;
    ArrayAdapter<String> mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Select A Script");

        final String[] fromColumns = {"Hamlet","Romeo and Juliet","A Midsummer's night dream","Othello","Macbeth"};

         class CustomListAdapter extends ArrayAdapter <String> {
            public CustomListAdapter(Context context, int resource, int textViewResourceId, String[] objects) {
                super(context, resource, textViewResourceId, objects);
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {


                View view =  super.getView(position, convertView, parent);
                final Typeface tvFont = Typeface.createFromAsset(getAssets(), "Playfair.ttf");

                TextView tv = (TextView) view.findViewById(R.id.produjct_name);
                tv.setTypeface(tvFont);

                return view;
            }


        }


        mAdapter = new CustomListAdapter(this, R.layout.list_item, R.id.produjct_name,fromColumns);
        ListView listView = (ListView) findViewById(R.id.list);
        inputSearch = (EditText) findViewById(R.id.inputSearch);
        listView.setAdapter(mAdapter);
        listView.setOnItemClickListener(new OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id){
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                String message = fromColumns[position];
                intent.putExtra("strname", message);
                startActivity(intent);
            }
        });




        inputSearch.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
                MainActivity.this.mAdapter.getFilter().filter(cs);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {

            }

            @Override
            public void afterTextChanged(Editable arg0) {
            }
        });


        Typeface font = Typeface.createFromAsset(getAssets(),"Playfair.ttf");
        TextView tv=(TextView) findViewById(R.id.inputSearch);
        tv.setTypeface(font);
        Button tv1=(Button) findViewById(R.id.upload);
        tv1.setTypeface(font);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        return true;
    }
    public void onClick(View view)
    {
        startActivity(new Intent("android.intent.SecondActivity"));
    }



}
