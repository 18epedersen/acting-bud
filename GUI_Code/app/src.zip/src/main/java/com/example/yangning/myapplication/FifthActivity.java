package com.example.yangning.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.content.Context;
import android.app.SearchManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class FifthActivity extends AppCompatActivity {
    Button next;
    Button back;
    ImageButton flip_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        Bundle bundle = getIntent().getExtras();
        next = (Button) findViewById(R.id.next5);
        back = (Button) findViewById(R.id.back5);
        flip_back = (ImageButton) findViewById(R.id.flip1);
        if(bundle.getString("strname")!= null)
        {
            actionBar.setTitle(bundle.getString("strname"));
        }
        flip_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.activity_fourth);
            }
        });
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.activity_threepointfive);
            }
        });
        next.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.flashcard3);
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
    public void onClick(View view)
    {
        startActivity(new Intent("android.intent.SecondActivity"));
    }
}