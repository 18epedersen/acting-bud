package com.example.yangning.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ChooseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Select The Way To Practice");
        Bundle bundle = getIntent().getExtras();
        final String kk = bundle.getString("strname");
        Button voice = (Button) findViewById(R.id.button2);
        Button flashcard = (Button) findViewById(R.id.button3);
        voice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseActivity.this, VoiceActivity.class);
                intent.putExtra("strname",kk);
                startActivity(intent);
            }
        });
        flashcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseActivity.this, FourthActivity.class);
                intent.putExtra("strname",kk);
                startActivity(intent);
            }
        });


    }
}
