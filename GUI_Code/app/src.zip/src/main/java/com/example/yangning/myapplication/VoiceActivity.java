package com.example.yangning.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.content.Context;
import android.app.SearchManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class VoiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.direct_to_voice);
        Bundle bundle = getIntent().getExtras();
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        if(bundle.getString("strname")!= null)
        {
            actionBar.setTitle(bundle.getString("strname"));

        }
        final String kk = bundle.getString("strname");
        Button back = (Button) findViewById(R.id.back4);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_threepointfive);
                Intent intent = new Intent(VoiceActivity.this, ChooseActivity.class);
                intent.putExtra("strname",kk);
                startActivity(intent);
            }
        });
    }


}
